import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Activity, AlertTriangle, BarChart3, Users, CheckCircle, Clock } from "lucide-react";

const PlatformSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="platform" ref={ref} className="section-padding relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[150px]" />

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-heading text-sm font-semibold uppercase tracking-widest">Smart Technology</span>
          <h2 className="font-heading text-3xl md:text-5xl font-bold mt-3">
            More Than a Website —{" "}
            <span className="text-primary">A Platform</span>
          </h2>
          <p className="text-muted-foreground text-lg mt-4 max-w-2xl mx-auto">
            Intelligent case management, urgency detection, and volunteer coordination — all in one digital welfare system.
          </p>
        </motion.div>

        {/* Dashboard mockup */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="glass-panel-strong p-6 md:p-8 glow-orange max-w-5xl mx-auto"
        >
          {/* Top bar */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Activity size={20} className="text-primary" />
              <span className="font-heading font-semibold">SevaSetu Dashboard</span>
            </div>
            <div className="flex gap-2">
              <div className="w-3 h-3 rounded-full bg-destructive/60" />
              <div className="w-3 h-3 rounded-full bg-primary/60" />
              <div className="w-3 h-3 rounded-full bg-secondary/60" />
            </div>
          </div>

          <div className="grid md:grid-cols-4 gap-4 mb-6">
            {[
              { label: "Active Cases", value: "24", icon: AlertTriangle, color: "text-primary" },
              { label: "Resolved Today", value: "8", icon: CheckCircle, color: "text-secondary" },
              { label: "Volunteers Online", value: "15", icon: Users, color: "text-primary" },
              { label: "Avg Response", value: "2.4h", icon: Clock, color: "text-secondary" },
            ].map((stat) => (
              <div key={stat.label} className="glass-panel p-4">
                <stat.icon size={16} className={`${stat.color} mb-2`} />
                <div className="font-heading text-2xl font-bold">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Cases list */}
          <div className="glass-panel p-4 space-y-3">
            <div className="text-sm font-heading font-semibold mb-2 flex items-center gap-2">
              <BarChart3 size={14} className="text-primary" /> Recent Cases
            </div>
            {[
              { id: "SVS-001", type: "Elderly Care", priority: "HIGH", status: "In Progress", color: "bg-destructive" },
              { id: "SVS-002", type: "Medicine Delivery", priority: "MEDIUM", status: "Assigned", color: "bg-primary" },
              { id: "SVS-003", type: "Welfare Check", priority: "LOW", status: "Resolved", color: "bg-secondary" },
            ].map((c) => (
              <div key={c.id} className="flex items-center justify-between glass-panel p-3">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${c.color}`} />
                  <span className="text-sm font-medium">{c.id}</span>
                  <span className="text-xs text-muted-foreground">{c.type}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-xs font-semibold ${c.priority === "HIGH" ? "text-destructive" : c.priority === "MEDIUM" ? "text-primary" : "text-secondary"}`}>
                    {c.priority}
                  </span>
                  <span className="text-xs text-muted-foreground">{c.status}</span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default PlatformSection;
