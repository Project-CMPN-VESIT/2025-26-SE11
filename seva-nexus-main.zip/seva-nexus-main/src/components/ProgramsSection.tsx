import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Heart, AlertTriangle, Users, HandHeart, GraduationCap, Megaphone } from "lucide-react";

const programs = [
  { title: "Elderly Care Support", desc: "Comprehensive welfare services for senior citizens including daily check-ins, medical coordination, and emotional support.", icon: Heart, accent: "primary", size: "large" },
  { title: "Case Reporting System", desc: "Smart digital reporting for urgent welfare cases with priority detection.", icon: AlertTriangle, accent: "primary", size: "small" },
  { title: "Volunteer Network", desc: "Coordinated volunteer assignments for visits, medicine delivery, and care.", icon: Users, accent: "secondary", size: "small" },
  { title: "Donation Platform", desc: "Transparent donation system supporting elderly care and education programs.", icon: HandHeart, accent: "primary", size: "medium" },
  { title: "Education Programs", desc: "MS-CIT, AI basics, Tally Prime, Advanced Excel — job-oriented digital training with placement support.", icon: GraduationCap, accent: "secondary", size: "medium" },
  { title: "Community Outreach", desc: "Awareness sessions, guidance programs, and grassroots community engagement.", icon: Megaphone, accent: "primary", size: "small" },
];

const ProgramsSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="programs" ref={ref} className="section-padding">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <span className="text-primary font-heading text-sm font-semibold uppercase tracking-widest">What We Do</span>
          <h2 className="font-heading text-3xl md:text-5xl font-bold mt-3">
            Our <span className="text-primary">Programs</span>
          </h2>
          <p className="text-muted-foreground text-lg mt-4 max-w-2xl">
            A holistic approach to village welfare — from emergency care to education, every program is designed for real impact.
          </p>
        </motion.div>

        {/* Asymmetrical masonry-like grid */}
        <div className="grid grid-cols-1 md:grid-cols-6 gap-6">
          {programs.map((p, i) => {
            const colSpan = p.size === "large" ? "md:col-span-3" : p.size === "medium" ? "md:col-span-3" : "md:col-span-2";
            const isAccentPrimary = p.accent === "primary";
            return (
              <motion.div
                key={p.title}
                initial={{ opacity: 0, y: 40 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.1 * i }}
                className={`${colSpan} glass-panel-strong p-8 hover-lift group relative overflow-hidden`}
              >
                <div className={`absolute -top-10 -right-10 w-32 h-32 rounded-full blur-3xl transition-all duration-700 ${
                  isAccentPrimary ? "bg-primary/5 group-hover:bg-primary/10" : "bg-secondary/5 group-hover:bg-secondary/10"
                }`} />
                <div className="relative z-10">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-5 ${
                    isAccentPrimary ? "bg-primary/10" : "bg-secondary/10"
                  }`}>
                    <p.icon size={24} className={isAccentPrimary ? "text-primary" : "text-secondary"} />
                  </div>
                  <h3 className="font-heading text-xl font-bold mb-3">{p.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{p.desc}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default ProgramsSection;
