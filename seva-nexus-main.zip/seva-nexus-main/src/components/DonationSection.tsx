import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";
import { Heart, GraduationCap, Home, ArrowRight, Copy, Check, QrCode, CreditCard, Smartphone } from "lucide-react";

const bankDetails = {
  accountName: "Siddhant Samaj Vikas Sanstha",
  bankName: "Bank of Maharashtra",
  accountNumber: "60404979289",
  ifsc: "MAHB0001234",
  branch: "Ulhasnagar Branch",
  upiId: "siddhantsevasetu@upi",
};

const DonationSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });
  const [copied, setCopied] = useState("");
  const [showDetails, setShowDetails] = useState(false);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(""), 2000);
  };

  return (
    <section id="donate" ref={ref} className="relative py-32 px-6 overflow-hidden">
      {/* Background glow */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/8 rounded-full blur-[150px]" />

      <div className="max-w-5xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <div className="inline-flex items-center gap-2 glass-panel px-4 py-2 mb-6">
            <Heart size={14} className="text-primary" />
            <span className="text-sm text-muted-foreground">Every contribution matters</span>
          </div>

          <h2 className="font-heading text-4xl md:text-6xl font-bold leading-tight">
            Your Support Can{" "}
            <span className="text-primary glow-text-orange">Change Lives</span>
          </h2>

          <p className="text-muted-foreground text-lg md:text-xl mt-6 max-w-2xl mx-auto leading-relaxed">
            Fund elderly care, power education programs, and keep the wheels of community welfare turning. 
            100% of donations directly impact lives in Ulhasnagar.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="grid md:grid-cols-3 gap-6 mt-14"
        >
          {[
            { title: "Elderly Care", desc: "Daily meals, medical support, and companionship for senior citizens", icon: Home, amount: "₹500" },
            { title: "Education Fund", desc: "Sponsor an MS-CIT or AI course seat for an underprivileged student", icon: GraduationCap, amount: "₹1,000" },
            { title: "NGO Operations", desc: "Support volunteer coordination, outreach, and infrastructure", icon: Heart, amount: "₹2,000" },
          ].map((item) => (
            <div key={item.title} className="glass-panel-strong p-7 hover-lift group text-center">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-5 group-hover:bg-primary/20 transition-colors">
                <item.icon size={26} className="text-primary" />
              </div>
              <h3 className="font-heading text-xl font-bold mb-2">{item.title}</h3>
              <p className="text-muted-foreground text-sm mb-4">{item.desc}</p>
              <div className="text-2xl font-heading font-bold text-primary mb-1">{item.amount}</div>
              <span className="text-xs text-muted-foreground">per month</span>
            </div>
          ))}
        </motion.div>

        {/* Donate Now CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-center mt-12"
        >
          <button
            onClick={() => setShowDetails(!showDetails)}
            className="btn-glow text-lg !px-12 !py-5 inline-flex items-center gap-3 group"
          >
            <Heart size={20} />
            {showDetails ? "Hide Payment Details" : "Donate Now"}
            <ArrowRight size={18} className={`transition-transform ${showDetails ? "rotate-90" : "group-hover:translate-x-1"}`} />
          </button>
        </motion.div>

        {/* Bank Details + QR Code */}
        {showDetails && (
          <motion.div
            initial={{ opacity: 0, y: 30, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            transition={{ duration: 0.5 }}
            className="mt-10 grid md:grid-cols-2 gap-6"
          >
            {/* Bank Account Details */}
            <div className="glass-panel-strong p-7 space-y-4">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                  <CreditCard size={20} className="text-primary" />
                </div>
                <h3 className="font-heading text-lg font-bold">Bank Transfer</h3>
              </div>

              {[
                { label: "Account Name", value: bankDetails.accountName },
                { label: "Bank", value: bankDetails.bankName },
                { label: "Account No.", value: bankDetails.accountNumber },
                { label: "IFSC Code", value: bankDetails.ifsc },
                { label: "Branch", value: bankDetails.branch },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between glass-panel p-3 rounded-xl">
                  <div>
                    <div className="text-xs text-muted-foreground">{item.label}</div>
                    <div className="text-sm font-medium text-foreground">{item.value}</div>
                  </div>
                  <button
                    onClick={() => copyToClipboard(item.value, item.label)}
                    className="text-muted-foreground hover:text-primary transition-colors p-1.5"
                    title={`Copy ${item.label}`}
                  >
                    {copied === item.label ? <Check size={14} className="text-secondary" /> : <Copy size={14} />}
                  </button>
                </div>
              ))}
            </div>

            {/* UPI / QR Code */}
            <div className="glass-panel-strong p-7 flex flex-col items-center justify-center text-center space-y-5">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-secondary/20 flex items-center justify-center">
                  <Smartphone size={20} className="text-secondary" />
                </div>
                <h3 className="font-heading text-lg font-bold">UPI Payment</h3>
              </div>

              {/* QR Code placeholder - replace with actual QR image */}
              <div className="w-48 h-48 rounded-2xl bg-foreground/90 flex items-center justify-center p-4">
                <div className="w-full h-full rounded-xl bg-background flex flex-col items-center justify-center gap-2">
                  <QrCode size={60} className="text-primary" />
                  <span className="text-xs text-muted-foreground">Scan to Pay</span>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">UPI ID</p>
                <div className="flex items-center gap-2">
                  <code className="text-primary font-mono text-sm glass-panel px-3 py-1.5 rounded-lg">
                    {bankDetails.upiId}
                  </code>
                  <button
                    onClick={() => copyToClipboard(bankDetails.upiId, "UPI")}
                    className="text-muted-foreground hover:text-primary transition-colors"
                  >
                    {copied === "UPI" ? <Check size={14} className="text-secondary" /> : <Copy size={14} />}
                  </button>
                </div>
              </div>

              <a
                href={`upi://pay?pa=${bankDetails.upiId}&pn=${encodeURIComponent(bankDetails.accountName)}&cu=INR`}
                className="btn-outline-glow !border-secondary/50 !text-secondary hover:!bg-secondary/10 hover:!border-secondary text-sm flex items-center gap-2"
              >
                <Smartphone size={16} />
                Open UPI App
              </a>
            </div>
          </motion.div>
        )}
      </div>
    </section>
  );
};

export default DonationSection;
