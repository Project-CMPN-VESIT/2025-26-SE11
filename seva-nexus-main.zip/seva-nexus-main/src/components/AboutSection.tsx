import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

const AboutSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" ref={ref} className="section-padding relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        {/* Editorial layout */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* Left: stacked images */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="lg:col-span-5 relative"
          >
            <div className="relative">
              <img
                src="/uploads/women-training-session.jpg"
                alt="Women attending a Siddhant Samaj Vikas Sanstha training session"
                className="rounded-2xl w-full object-cover aspect-[4/5]"
                loading="lazy"
                width={800}
                height={1024}
              />
              <div className="absolute -bottom-6 -right-6 w-48 h-48 md:w-56 md:h-56 rounded-2xl overflow-hidden border-4 border-background shadow-2xl">
                <img
                  src="/uploads/social-awareness-board.jpg"
                  alt="Social awareness classroom board at Siddhant Samaj Vikas Sanstha"
                  className="w-full h-full object-cover"
                  loading="lazy"
                  width={1024}
                  height={1024}
                />
              </div>
            </div>
          </motion.div>

          {/* Right: storytelling text */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-7 space-y-8 lg:pt-12"
          >
            <div>
              <span className="text-primary font-heading text-sm font-semibold uppercase tracking-widest">Our Story</span>
              <h2 className="font-heading text-3xl md:text-5xl font-bold mt-3 leading-tight">
                From the Ground Up,{" "}
                <span className="text-primary">For the People</span>
              </h2>
            </div>

            <div className="space-y-6 text-muted-foreground text-lg leading-relaxed">
              <p>
                In the lanes of Ulhasnagar, behind Sindh National Gangaram School, a quiet revolution began.{" "}
                <strong className="text-foreground">Siddhant Samaj Vikas Sanstha</strong> witnessed firsthand what happens when 
                elderly citizens are forgotten — delayed help, manual reporting systems that failed, and communities disconnected 
                from the support they desperately needed.
              </p>
              <p>
                The problems were clear: <span className="text-foreground">no digital infrastructure</span> for case reporting, 
                no way to prioritize urgent needs, and volunteers working without coordination. Traditional approaches were too slow 
                for the urgency of real lives.
              </p>
            </div>

            <div className="glass-panel p-6 border-l-4 border-l-primary">
              <p className="text-foreground font-medium italic text-lg">
                "SevaSetu was born from necessity — a smart system that connects those who need help with those who can provide it, instantly."
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="glass-panel p-5 hover-lift">
                <div className="text-3xl font-heading font-bold text-primary">7+</div>
                <div className="text-sm text-muted-foreground mt-1">Years of Ground Work</div>
              </div>
              <div className="glass-panel p-5 hover-lift">
                <div className="text-3xl font-heading font-bold text-secondary">100%</div>
                <div className="text-sm text-muted-foreground mt-1">Community Driven</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
