import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { MapPin, Pill, HandHeart, BookOpen, ArrowRight } from "lucide-react";

const roles = [
  { title: "Home Visits", desc: "Regular visits to elderly citizens for check-ins and companionship", icon: MapPin },
  { title: "Medicine Support", desc: "Coordinate medicine delivery and pharmacy pickups", icon: Pill },
  { title: "Donation Drives", desc: "Organize and participate in community donation campaigns", icon: HandHeart },
  { title: "Education Support", desc: "Assist in teaching MS-CIT, Excel, and digital skills", icon: BookOpen },
];

const VolunteerSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="section-padding">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7 }}
          >
            <span className="text-secondary font-heading text-sm font-semibold uppercase tracking-widest">Join Us</span>
            <h2 className="font-heading text-3xl md:text-5xl font-bold mt-3 leading-tight">
              Become a <span className="text-secondary">Volunteer</span>
            </h2>
            <p className="text-muted-foreground text-lg mt-4 leading-relaxed max-w-lg">
              Be part of a movement that brings dignity, care, and education to those who need it most. 
              Every hour you give transforms a life.
            </p>
            <a href="#contact" className="btn-glow !bg-secondary inline-flex items-center gap-2 mt-8 group" style={{ boxShadow: "0 0 20px -5px hsl(150 40% 40% / 0.5)" }}>
              Join as Volunteer
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </a>
          </motion.div>

          <div className="grid grid-cols-2 gap-4">
            {roles.map((role, i) => (
              <motion.div
                key={role.title}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.2 + i * 0.1 }}
                className="glass-panel p-6 hover-lift group"
              >
                <div className="w-10 h-10 rounded-xl bg-secondary/10 flex items-center justify-center mb-4 group-hover:bg-secondary/20 transition-colors">
                  <role.icon size={20} className="text-secondary" />
                </div>
                <h4 className="font-heading font-bold mb-2">{role.title}</h4>
                <p className="text-muted-foreground text-sm">{role.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default VolunteerSection;
