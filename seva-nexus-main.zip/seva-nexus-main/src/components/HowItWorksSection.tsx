import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { FileText, Database, Zap, UserCheck, HeartHandshake, CheckCircle2 } from "lucide-react";

const steps = [
  { title: "Report", desc: "Citizen or volunteer submits a welfare case", icon: FileText },
  { title: "Store", desc: "Case is securely stored in the system", icon: Database },
  { title: "Prioritize", desc: "AI-assisted urgency detection (High/Medium/Low)", icon: Zap },
  { title: "Assign", desc: "Nearest available volunteer is notified", icon: UserCheck },
  { title: "Support", desc: "On-ground assistance and care delivery", icon: HeartHandshake },
  { title: "Resolve", desc: "Case closed with documented outcome", icon: CheckCircle2 },
];

const HowItWorksSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="section-padding">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-heading text-sm font-semibold uppercase tracking-widest">The Process</span>
          <h2 className="font-heading text-3xl md:text-5xl font-bold mt-3">
            How <span className="text-primary">It Works</span>
          </h2>
        </motion.div>

        {/* Winding path */}
        <div className="relative max-w-4xl mx-auto">
          {/* Vertical line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-primary/50 via-primary/20 to-secondary/50 hidden md:block" />

          {steps.map((step, i) => {
            const isLeft = i % 2 === 0;
            return (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, x: isLeft ? -50 : 50 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.15 * i }}
                className={`relative flex items-center gap-6 mb-12 ${
                  isLeft ? "md:flex-row" : "md:flex-row-reverse"
                } flex-row`}
              >
                {/* Content */}
                <div className={`flex-1 ${isLeft ? "md:text-right" : "md:text-left"}`}>
                  <div className={`glass-panel p-6 hover-lift inline-block ${isLeft ? "md:ml-auto" : ""}`}>
                    <div className="flex items-center gap-3 mb-2" style={{ flexDirection: isLeft ? "row-reverse" : "row" }}>
                      <span className="text-xs text-primary font-heading font-bold">0{i + 1}</span>
                      <h4 className="font-heading text-lg font-bold">{step.title}</h4>
                    </div>
                    <p className="text-muted-foreground text-sm">{step.desc}</p>
                  </div>
                </div>

                {/* Center node */}
                <div className="w-12 h-12 rounded-full glass-panel-strong flex items-center justify-center shrink-0 z-10 glow-orange">
                  <step.icon size={20} className="text-primary" />
                </div>

                {/* Spacer */}
                <div className="flex-1 hidden md:block" />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
