import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Shield, Award, MapPin } from "lucide-react";

const TrustSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="section-padding">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="glass-panel-strong p-10 md:p-14 text-center relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary via-secondary to-primary" />
          
          <div className="flex justify-center gap-8 mb-8">
            {[
              { icon: Shield, label: "Registered NGO" },
              { icon: Award, label: "Verified Impact" },
              { icon: MapPin, label: "Ulhasnagar Based" },
            ].map((item) => (
              <div key={item.label} className="flex flex-col items-center gap-2">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <item.icon size={22} className="text-primary" />
                </div>
                <span className="text-xs text-muted-foreground">{item.label}</span>
              </div>
            ))}
          </div>

          <h3 className="font-heading text-2xl md:text-3xl font-bold mb-4">
            Real NGO. Real Work. <span className="text-primary">Real Impact.</span>
          </h3>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto leading-relaxed">
            Siddhant Samaj Vikas Sanstha is a registered non-governmental organization operating from 
            Ulhasnagar, Maharashtra. Every program, every case, every student represents real, 
            measurable change in our community.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default TrustSection;
