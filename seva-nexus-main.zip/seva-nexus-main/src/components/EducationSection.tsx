import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Monitor, Brain, BarChart3, FileSpreadsheet, Briefcase, ArrowRight } from "lucide-react";

const courses = [
  { title: "MS-CIT", desc: "Maharashtra State Certificate in IT — government recognized digital literacy program", icon: Monitor, duration: "3 Months" },
  { title: "AI Fundamentals", desc: "Introduction to Artificial Intelligence concepts and real-world applications", icon: Brain, duration: "6 Weeks" },
  { title: "Tally Prime + GST", desc: "Complete accounting with GST compliance for job readiness", icon: BarChart3, duration: "2 Months" },
  { title: "Advanced Excel", desc: "Data analysis, pivot tables, macros, and business intelligence skills", icon: FileSpreadsheet, duration: "6 Weeks" },
];

const EducationSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="education" ref={ref} className="section-padding relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-secondary/5 rounded-full blur-[120px]" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: content */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6 }}
            >
              <span className="text-secondary font-heading text-sm font-semibold uppercase tracking-widest">Education Programs</span>
              <h2 className="font-heading text-3xl md:text-5xl font-bold mt-3 leading-tight">
                Empowering Through{" "}
                <span className="text-secondary">Digital Skills</span>
              </h2>
              <p className="text-muted-foreground text-lg mt-4 leading-relaxed">
                Job-oriented training programs with placement support — transforming lives through technology education in Ulhasnagar.
              </p>
            </motion.div>

            <div className="mt-10 space-y-4">
              {courses.map((course, i) => (
                <motion.div
                  key={course.title}
                  initial={{ opacity: 0, x: -30 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.2 + i * 0.1 }}
                  className="glass-panel p-5 flex items-start gap-4 hover-lift group cursor-pointer"
                >
                  <div className="w-11 h-11 rounded-xl bg-secondary/10 flex items-center justify-center shrink-0 group-hover:bg-secondary/20 transition-colors">
                    <course.icon size={20} className="text-secondary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-heading font-bold text-lg">{course.title}</h4>
                      <span className="text-xs text-muted-foreground glass-panel px-3 py-1">{course.duration}</span>
                    </div>
                    <p className="text-muted-foreground text-sm mt-1">{course.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="mt-8 flex flex-wrap gap-4"
            >
              <a href="#contact" className="btn-glow !bg-secondary flex items-center gap-2 group" style={{ boxShadow: "0 0 20px -5px hsl(150 40% 40% / 0.5)" }}>
                <Briefcase size={18} />
                Enroll Now
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </a>
              <span className="text-muted-foreground text-sm self-center">Placement support included</span>
            </motion.div>
          </div>

          {/* Right: image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={inView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative"
          >
            <div className="rounded-3xl overflow-hidden relative">
              <img
                src="/uploads/mscIT-computer-lab.jpg"
                alt="Students learning MS-CIT computer skills at Siddhant training centre"
                className="w-full object-cover aspect-square"
                loading="lazy"
                width={1024}
                height={1024}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 glass-panel-strong p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm text-muted-foreground">Students Trained</div>
                    <div className="text-3xl font-heading font-bold text-secondary">500+</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-muted-foreground">Placement Rate</div>
                    <div className="text-3xl font-heading font-bold text-primary">85%</div>
                  </div>
                </div>
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-4 -right-4 w-24 h-24 border-2 border-secondary/20 rounded-2xl" />
            <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-secondary/10 rounded-xl blur-sm" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default EducationSection;
