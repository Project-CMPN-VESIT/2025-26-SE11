import { motion, useInView } from "framer-motion";
import { useRef, useState, useEffect } from "react";

function Counter({ value, suffix = "+" }: { value: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setStarted(true); },
      { threshold: 0.5 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    if (!started) return;
    let current = 0;
    const step = value / 60;
    const timer = setInterval(() => {
      current += step;
      if (current >= value) { setCount(value); clearInterval(timer); }
      else setCount(Math.floor(current));
    }, 25);
    return () => clearInterval(timer);
  }, [started, value]);

  return (
    <div ref={ref} className="font-heading text-5xl md:text-7xl font-bold text-primary counter-glow">
      {count.toLocaleString()}{suffix}
    </div>
  );
}

const stats = [
  { value: 500, label: "Students Trained", suffix: "+" },
  { value: 250, label: "Elderly Supported", suffix: "+" },
  { value: 120, label: "Volunteers Connected", suffix: "+" },
  { value: 300, label: "Cases Handled", suffix: "+" },
];

const ImpactSection = () => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="impact" ref={ref} className="section-padding relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/3 via-transparent to-secondary/3" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-16"
        >
          <span className="text-primary font-heading text-sm font-semibold uppercase tracking-widest">Real Numbers</span>
          <h2 className="font-heading text-3xl md:text-5xl font-bold mt-3">
            Our <span className="text-primary">Impact</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              className="text-center glass-panel p-8 hover-lift"
            >
              <Counter value={stat.value} suffix={stat.suffix} />
              <div className="text-muted-foreground mt-3 font-medium">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ImpactSection;
