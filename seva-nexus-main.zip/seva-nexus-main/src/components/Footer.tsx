import { Heart } from "lucide-react";

const Footer = () => (
  <footer className="border-t border-border py-12 px-6">
    <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-primary/20 border border-primary/30 flex items-center justify-center">
          <span className="font-heading font-bold text-primary text-sm">S</span>
        </div>
        <span className="font-heading font-semibold text-sm">
          Siddhant <span className="text-primary">SevaSetu</span>
        </span>
      </div>
      <p className="text-muted-foreground text-sm text-center">
        © 2025 Siddhant Samaj Vikas Sanstha, Ulhasnagar. All rights reserved.
      </p>
      <div className="flex items-center gap-1 text-sm text-muted-foreground">
        Built with <Heart size={14} className="text-primary mx-1" /> for the community
      </div>
    </div>
  </footer>
);

export default Footer;
