import { useEffect, useState, useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight, Heart, Users, GraduationCap, Shield } from "lucide-react";

const counters = [
  { label: "Cases Resolved", value: 250, icon: Shield },
  { label: "Students Trained", value: 500, icon: GraduationCap },
  { label: "Volunteers Active", value: 120, icon: Users },
];

function AnimatedCounter({ value, duration = 2000 }: { value: number; duration?: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting && !started) setStarted(true); },
      { threshold: 0.5 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [started]);

  useEffect(() => {
    if (!started) return;
    let start = 0;
    const step = value / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= value) { setCount(value); clearInterval(timer); }
      else setCount(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [started, value, duration]);

  return <div ref={ref} className="font-heading text-5xl md:text-6xl font-bold text-primary counter-glow">{count}+</div>;
}

const HeroSection = () => {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  return (
    <section ref={ref} className="relative min-h-screen flex items-center overflow-hidden">
      {/* Parallax BG */}
      <motion.div style={{ y }} className="absolute inset-0 z-0">
        <img src="/uploads/ngo-community-event.jpg" alt="Siddhant Samaj Vikas Sanstha community event" className="w-full h-full object-cover" width={1920} height={1080} />
        <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/65 to-background" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-background/10" />
      </motion.div>

      <motion.div style={{ opacity }} className="relative z-10 w-full max-w-7xl mx-auto px-6 pt-32 pb-20">
        <div className="grid lg:grid-cols-5 gap-12 items-center">
          {/* Left Content */}
          <div className="lg:col-span-3 space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="inline-flex items-center gap-2 glass-panel px-4 py-2"
            >
              <Heart size={14} className="text-primary" />
              <span className="text-sm text-muted-foreground font-medium">Siddhant Samaj Vikas Sanstha, Ulhasnagar</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="font-heading text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.05] tracking-tight"
            >
              No Elderly Person{" "}
              <br />
              Should Be Left{" "}
              <span className="text-primary glow-text-orange">Unseen.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="text-muted-foreground text-lg md:text-xl max-w-xl leading-relaxed"
            >
              A smart village welfare platform connecting citizens, NGOs, volunteers, donors &amp; learners — 
              building dignity through care, education &amp; digital empowerment.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="flex flex-wrap gap-4"
            >
              <a href="/report-case" className="btn-glow flex items-center gap-2 group">
                Report a Case
                <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </a>
              <a href="#donate" className="btn-outline-glow">
                Donate Now
              </a>
              <a href="#programs" className="btn-outline-glow !border-secondary/50 !text-secondary hover:!bg-secondary/10 hover:!border-secondary">
                Explore Programs
              </a>
            </motion.div>
          </div>

          {/* Floating Glass Card */}
          <motion.div
            initial={{ opacity: 0, x: 60, rotateY: -10 }}
            animate={{ opacity: 1, x: 0, rotateY: 0 }}
            transition={{ duration: 1, delay: 1 }}
            className="lg:col-span-2 hidden lg:block"
          >
            <div className="glass-panel-strong p-6 animate-float glow-orange">
              <div className="text-xs text-muted-foreground mb-4 font-medium uppercase tracking-wider">System Preview</div>
              <div className="space-y-3">
                <div className="flex items-center justify-between glass-panel p-3">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-destructive animate-pulse-glow" />
                    <span className="text-sm">High Priority Case</span>
                  </div>
                  <span className="text-xs text-primary font-semibold">URGENT</span>
                </div>
                <div className="flex items-center justify-between glass-panel p-3">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-primary" />
                    <span className="text-sm">Volunteer Assigned</span>
                  </div>
                  <span className="text-xs text-secondary font-semibold">ACTIVE</span>
                </div>
                <div className="flex items-center justify-between glass-panel p-3">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-secondary" />
                    <span className="text-sm">MS-CIT Enrollment</span>
                  </div>
                  <span className="text-xs text-muted-foreground">OPEN</span>
                </div>
              </div>
              <div className="mt-4 h-20 glass-panel rounded-xl flex items-center justify-center">
                <div className="flex gap-2">
                  {[40, 65, 30, 80, 55, 70, 45].map((h, i) => (
                    <motion.div
                      key={i}
                      initial={{ height: 0 }}
                      animate={{ height: h + "%" }}
                      transition={{ duration: 1, delay: 1.2 + i * 0.1 }}
                      className="w-4 bg-gradient-to-t from-primary/60 to-primary rounded-t"
                    />
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Counters */}
        <div className="mt-16 grid grid-cols-1 sm:grid-cols-3 gap-6">
          {counters.map((c, i) => (
            <motion.div
              key={c.label}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 1.2 + i * 0.15 }}
              className="glass-panel p-6 flex items-center gap-5 hover-lift"
            >
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <c.icon size={22} className="text-primary" />
              </div>
              <div>
                <AnimatedCounter value={c.value} />
                <div className="text-sm text-muted-foreground mt-1">{c.label}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  );
};

export default HeroSection;
