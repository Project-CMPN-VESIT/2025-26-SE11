import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import MissionSection from "@/components/MissionSection";
import ProgramsSection from "@/components/ProgramsSection";
import EducationSection from "@/components/EducationSection";
import PlatformSection from "@/components/PlatformSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import DonationSection from "@/components/DonationSection";
import ImpactSection from "@/components/ImpactSection";
import VolunteerSection from "@/components/VolunteerSection";
import TrustSection from "@/components/TrustSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";

const Index = () => (
  <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
    <Navbar />
    <HeroSection />
    <AboutSection />
    <MissionSection />
    <ProgramsSection />
    <EducationSection />
    <PlatformSection />
    <HowItWorksSection />
    <DonationSection />
    <ImpactSection />
    <VolunteerSection />
    <TrustSection />
    <ContactSection />
    <Footer />
  </div>
);

export default Index;
