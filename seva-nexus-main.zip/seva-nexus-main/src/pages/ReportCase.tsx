import { useState, useRef } from "react";
import { motion } from "framer-motion";
import { Camera, MapPin, AlertTriangle, Send, ArrowLeft, X, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";

const severityOptions = [
  { value: "high", label: "High – Immediate attention needed", color: "text-destructive" },
  { value: "medium", label: "Medium – Needs help soon", color: "text-primary" },
  { value: "low", label: "Low – General support needed", color: "text-secondary" },
];

const caseTypes = [
  "Elderly person living alone",
  "Medical emergency",
  "Neglect or abandonment",
  "Need for daily essentials",
  "Mental health concern",
  "Other",
];

const ReportCase = () => {
  const [form, setForm] = useState({
    reporterName: "",
    reporterPhone: "",
    elderlyName: "",
    elderlyAge: "",
    address: "",
    caseType: "",
    severity: "medium",
    description: "",
    gpsLat: "",
    gpsLng: "",
  });
  const [photos, setPhotos] = useState<{ file: File; preview: string }[]>([]);
  const [locating, setLocating] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handlePhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const newPhotos = Array.from(files).slice(0, 3 - photos.length).map((file) => ({
      file,
      preview: URL.createObjectURL(file),
    }));
    setPhotos((prev) => [...prev, ...newPhotos].slice(0, 3));
  };

  const removePhoto = (index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
  };

  const getGPS = () => {
    if (!navigator.geolocation) return alert("GPS not supported on this device");
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setForm((prev) => ({
          ...prev,
          gpsLat: pos.coords.latitude.toFixed(6),
          gpsLng: pos.coords.longitude.toFixed(6),
        }));
        setLocating(false);
      },
      () => {
        alert("Unable to get location. Please enter address manually.");
        setLocating(false);
      },
      { enableHighAccuracy: true }
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const severityLabel = severityOptions.find((s) => s.value === form.severity)?.label || form.severity;
    const gpsText = form.gpsLat && form.gpsLng
      ? `GPS: https://maps.google.com/?q=${form.gpsLat},${form.gpsLng}`
      : "GPS: Not provided";

    const message = `🚨 *NEW WELFARE CASE REPORT*

*Reporter:* ${form.reporterName}
*Phone:* ${form.reporterPhone}

*Elderly Person:* ${form.elderlyName}
*Age:* ${form.elderlyAge}
*Address:* ${form.address}
${gpsText}

*Case Type:* ${form.caseType}
*Severity:* ${severityLabel}

*Description:*
${form.description}

*Photos:* ${photos.length} attached (please share in chat)

— Sent via Siddhant SevaSetu`;

    const encoded = encodeURIComponent(message);
    // Replace with actual WhatsApp number
    const whatsappNumber = "919876543210";
    window.open(`https://wa.me/${whatsappNumber}?text=${encoded}`, "_blank");
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="glass-panel-strong border-b border-border/30">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center gap-4">
          <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft size={20} />
          </Link>
          <div>
            <h1 className="font-heading text-xl font-bold">Report a Welfare Case</h1>
            <p className="text-sm text-muted-foreground">Help us reach those who need care</p>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-10">
        <motion.form
          onSubmit={handleSubmit}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-8"
        >
          {/* Reporter Info */}
          <div className="glass-panel p-6 space-y-5">
            <h2 className="font-heading text-lg font-semibold flex items-center gap-2">
              <span className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center text-primary text-sm font-bold">1</span>
              Your Information
            </h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-muted-foreground mb-1.5 block">Your Name *</label>
                <input
                  name="reporterName"
                  required
                  value={form.reporterName}
                  onChange={handleChange}
                  className="w-full glass-panel px-4 py-3 rounded-xl bg-transparent text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50"
                  placeholder="Enter your full name"
                />
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-1.5 block">Phone Number *</label>
                <input
                  name="reporterPhone"
                  required
                  type="tel"
                  value={form.reporterPhone}
                  onChange={handleChange}
                  className="w-full glass-panel px-4 py-3 rounded-xl bg-transparent text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50"
                  placeholder="+91 XXXXX XXXXX"
                />
              </div>
            </div>
          </div>

          {/* Elderly Person Details */}
          <div className="glass-panel p-6 space-y-5">
            <h2 className="font-heading text-lg font-semibold flex items-center gap-2">
              <span className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center text-primary text-sm font-bold">2</span>
              Elderly Person Details
            </h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-muted-foreground mb-1.5 block">Person's Name *</label>
                <input
                  name="elderlyName"
                  required
                  value={form.elderlyName}
                  onChange={handleChange}
                  className="w-full glass-panel px-4 py-3 rounded-xl bg-transparent text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50"
                  placeholder="Name of elderly person"
                />
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-1.5 block">Approximate Age</label>
                <input
                  name="elderlyAge"
                  type="number"
                  value={form.elderlyAge}
                  onChange={handleChange}
                  className="w-full glass-panel px-4 py-3 rounded-xl bg-transparent text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50"
                  placeholder="e.g. 75"
                />
              </div>
            </div>

            <div>
              <label className="text-sm text-muted-foreground mb-1.5 block">Address / Location *</label>
              <input
                name="address"
                required
                value={form.address}
                onChange={handleChange}
                className="w-full glass-panel px-4 py-3 rounded-xl bg-transparent text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50"
                placeholder="Full address or landmark"
              />
            </div>

            {/* GPS */}
            <div className="flex items-center gap-4">
              <button
                type="button"
                onClick={getGPS}
                disabled={locating}
                className="btn-outline-glow !py-2.5 !px-5 flex items-center gap-2 text-sm"
              >
                {locating ? <Loader2 size={16} className="animate-spin" /> : <MapPin size={16} />}
                {locating ? "Locating..." : "Auto-detect GPS Location"}
              </button>
              {form.gpsLat && (
                <span className="text-xs text-secondary">
                  📍 {form.gpsLat}, {form.gpsLng}
                </span>
              )}
            </div>
          </div>

          {/* Case Details */}
          <div className="glass-panel p-6 space-y-5">
            <h2 className="font-heading text-lg font-semibold flex items-center gap-2">
              <span className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center text-primary text-sm font-bold">3</span>
              Case Details
            </h2>

            <div>
              <label className="text-sm text-muted-foreground mb-1.5 block">Type of Case *</label>
              <select
                name="caseType"
                required
                value={form.caseType}
                onChange={handleChange}
                className="w-full glass-panel px-4 py-3 rounded-xl bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
              >
                <option value="">Select case type</option>
                {caseTypes.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>

            {/* Severity */}
            <div>
              <label className="text-sm text-muted-foreground mb-3 block">Severity Level *</label>
              <div className="grid sm:grid-cols-3 gap-3">
                {severityOptions.map((s) => (
                  <button
                    key={s.value}
                    type="button"
                    onClick={() => setForm({ ...form, severity: s.value })}
                    className={`glass-panel p-4 rounded-xl text-left transition-all ${
                      form.severity === s.value
                        ? "ring-2 ring-primary bg-primary/10"
                        : "hover:bg-muted/30"
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <AlertTriangle size={14} className={s.color} />
                      <span className={`text-sm font-semibold capitalize ${s.color}`}>{s.value}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{s.label.split(" – ")[1]}</p>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm text-muted-foreground mb-1.5 block">Description *</label>
              <textarea
                name="description"
                required
                value={form.description}
                onChange={handleChange}
                rows={4}
                className="w-full glass-panel px-4 py-3 rounded-xl bg-transparent text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                placeholder="Describe the situation in detail — what you observed, how long, any urgent needs..."
              />
            </div>
          </div>

          {/* Photo Upload */}
          <div className="glass-panel p-6 space-y-5">
            <h2 className="font-heading text-lg font-semibold flex items-center gap-2">
              <span className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center text-primary text-sm font-bold">4</span>
              Photo Evidence (Optional)
            </h2>
            <p className="text-sm text-muted-foreground">Take or upload up to 3 photos. These will help our team assess the situation.</p>

            <div className="flex flex-wrap gap-4">
              {photos.map((photo, i) => (
                <div key={i} className="relative w-28 h-28 rounded-xl overflow-hidden glass-panel">
                  <img src={photo.preview} alt={`Photo ${i + 1}`} className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => removePhoto(i)}
                    className="absolute top-1 right-1 w-6 h-6 rounded-full bg-background/80 flex items-center justify-center"
                  >
                    <X size={12} />
                  </button>
                </div>
              ))}
              {photos.length < 3 && (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-28 h-28 rounded-xl glass-panel flex flex-col items-center justify-center gap-2 text-muted-foreground hover:text-foreground hover:bg-muted/20 transition-colors"
                >
                  <Camera size={24} />
                  <span className="text-xs">Add Photo</span>
                </button>
              )}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              multiple
              onChange={handlePhotoCapture}
              className="hidden"
            />
          </div>

          {/* Submit */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="flex flex-col items-center gap-4"
          >
            <button type="submit" className="btn-glow text-lg !px-12 !py-5 flex items-center gap-3 group">
              <Send size={20} />
              Send Report via WhatsApp
              <ArrowLeft size={18} className="rotate-180 group-hover:translate-x-1 transition-transform" />
            </button>
            <p className="text-xs text-muted-foreground text-center max-w-md">
              Your report will be pre-filled and sent via WhatsApp to our welfare team. 
              Photos can be shared directly in the WhatsApp chat.
            </p>
          </motion.div>
        </motion.form>
      </div>
    </div>
  );
};

export default ReportCase;
